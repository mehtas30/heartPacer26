# heartPacer26
Heart Pacer Project for 3K04
Members:
Samarth,
Patrick,
Josh,
Burhanuddin,
Saransh
