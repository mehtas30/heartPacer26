# heartPacer26
Heart Pacer Project for 3K04
Members:
Samarth,
Patrick,
Josh,
Burhanuddin,
Saransh


For marking A1 please use code in zip file. 
To run gui- run "gui.py" tkinter and sqlite used... these should be native to python already. 

For A2 please see zip file
Will need tkinter, sqlite3, matplotlib, pySerial, PIL
